<?php

class User_model extends CI_Model {

	// method untuk membaca data profile user
	public function getUserProfile($username){
		$query = $this->db->get_where('user', array('username' => $username));
		return $query->row_array();
	}

	public function showUser(){
		$query = $this->db->get('user');
		return $query->result_array();
	}

	public function insertUser($username, $password, $fullname, $role){
		$data = array(
				"username" => $username,
				"password" => $password,
				"fullname" => $fullname,
				"role" => $role
		);
		$query = $this->db->insert('user', $data);
	}

	public function editUser($username, $password, $fullname, $role){
		$query = $this->db->get('user');
		return $query->result_array();
		
		$data = array(
				"username" => $username,
				"password" => $password,
				"fullname" => $fullname,
				"role" => $role
		);
		$query = $this->db->insert('user', $data);
	}


	public function deluser($username){
		$this->db->delete('user', array("username" => $username));
	}

	public function updateUser($username, $fullname, $password, $role){
			$data = array(
				"fullname" => $fullname,
				"password" => $password,
				"role" => $role
			);
		$this->db->update('user', $data, 'username= "' . $username .'"');
	}

		public function getRole(){
		$query=$this->db->get('role');
		return $query -> result_array();
	}

		public function getUser(){
		$query=$this->db->get('user');
		return $query -> result_array();
	}

	
}

?>