<?php

class Kategori_model extends CI_Model {

	// method untuk menampilkan data buku
	public function showKategori(){
			$query = $this->db->get('kategori');
			return $query->result_array();
		} 
	
	public function getUserProfile($idkategori){
		$query = $this->db->get_where('kategori', array('idkategori' => $idkategori));
		return $query->row_array();
	}

	// method untuk hapus data buku berdasarkan id
	public function delKat($idkategori){
		$this->db->delete('kategori', array("idkategori" => $idkategori));
	}


	// method untuk insert data buku ke tabel 'books'
	public function insertKategori($idkategori, $kategori){
		$data = array(
				"idkategori" => $idkategori,
				"kategori" => $kategori
		);
		$query = $this->db->insert('kategori', $data);
	}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getKategori(){
		$query = $this->db->get('kategori');
		return $query->result_array();
	}

	public function editKat($idkategori, $kategori){
		$query = $this->db->get('kategori');
		return $query->result_array();
		
		$data = array(
				"idkategori" => $idkategori,
				"kategori" => $kategori
		);
		$query = $this->db->insert('kategori', $data);
	}

	// method untuk menghitung jumlah buku berdasarkan idkategori
	public function countByCat($idkategori){
		$query = $this->db->query("SELECT count(*) as jum FROM books WHERE idkategori = '$idkategori'");
		return $query->row()->jum;
	}

}
?>