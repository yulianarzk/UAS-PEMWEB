<?php
class Dashboard extends CI_Controller {

        public function __construct(){
            parent::__construct();

            // cek keberadaan session 'username'    
            if (!isset($_SESSION['username'])){
                // jika session 'username' blm ada, maka arahkan ke kontroller 'login'
                redirect('login');
            }
        }

        public function delete($username){
        $this->user_model->deluser($username);
        // arahkan ke method 'books' di kontroller 'dashboard'
        redirect('dashboard/user');
        }

        public function edit($username){
            $data['view_user'] = $this->user_model->getUserProfile($username);
            $data['fullname'] = $_SESSION['fullname'];

            if (empty($data['view_user'])){
                show_404();
            }    

        $data['username'] = $data['view_user']['username'];
        $data['password'] = $data['view_user']['password'];
        $data['fullname'] = $data['view_user']['fullname'];
        $data['role'] = $data['view_user']['role'];

            $this->load->view('dashboard/header', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('dashboard/footer');
            
         }

        public function insert(){

        // baca data dari form insert buku
        $username = $_POST['username'];
        $password = $_POST['password'];
        $fullname = $_POST['fullname'];
        $role = $_POST['role'];

        // panggil method insertBook() di model 'book_model' untuk menjalankan query insert
        $this->user_model->insertUser($username, $password, $fullname, $role);

        // arahkan ke method 'books' di kontroller 'dashboard'
        redirect('dashboard/user');
    }


    public function update(){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $fullname = $_POST['fullname'];
        $role = $_POST['role'];
    

    $this->user_model->updateUser($username, $password, $fullname, $role);
    redirect('dashboard/user');
}

}