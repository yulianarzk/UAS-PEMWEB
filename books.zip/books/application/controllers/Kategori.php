<?php
class Kategori extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($idkategori){
		$this->kategori_model->delKat($idkategori);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	public function hitung(){
		$this->kategori_model->countByCat($idkategori);
	}

	public function insert(){

		// baca data dari form insert buku
		$idkategori = $_POST['idkategori'];
		$kategori = $_POST['kategori'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->kategori_model->insertKategori($idkategori, $kategori);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	   public function edit($idkategori){
            $data['view_kategori'] = $this->kategori_model->getUserProfile($idkategori);
            $data['fullname'] = $_SESSION['fullname'];

            if (empty($data['view_kategori'])){
                show_404();
            }    

        $data['idkategori'] = $data['view_kategori']['idkategori'];
        $data['kategori'] = $data['view_kategori']['kategori'];

            $this->load->view('dashboard/header', $data);
            $this->load->view('kategori/edit', $data);
            $this->load->view('dashboard/footer');
         }


    public function update(){
    $idkategori = $_POST['idkategori'];
     $kategori = $_POST['kategori'];


    $this->kategori_model->updateKategori($idkategori, $kategori);
    redirect('dashboard/kategori');
}

}
?>