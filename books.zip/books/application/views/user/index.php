    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Daftar User</h1>
      </div>

  <form action="<?php echo site_url('dashboard/adduser'); ?>">
    <div class="panel-heading" style="float: right; padding: 15px; size: 40px">
      <button>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg> Tambah User
      </button>
    </div>
  </form>


      <div class="table-responsive">
        <table class="table">
          <thread>
            <tr>
              <th>Username</th>
              <th>Password</th>
              <th>Fullname</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thread>
        <tbody>

            <?php
            foreach ($user as $user_item) :
            ?>

            <tr>
              <td><?php echo $user_item['username']?></td>
              <td><?php echo $user_item['password']?></td>
              <td><?php echo $user_item['fullname']?></td>
              <td><?php echo $user_item['role']?></td>
              <td> <?php echo anchor('user/edit'.$user_item['username'], 'Edit', 'Edit User'); ?> | <?php echo anchor('user/delete'.$user_item['username'], 'Delete', 'Hapus User'); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </main>
  