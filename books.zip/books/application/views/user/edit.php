  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4"><div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit User</h1>
      </div>

    <?php foreach ($user as $u){ ?>
  <form action="<?php echo base_url(). 'user/edit'; ?>" method="post">

          <table style="margin:20px auto;">
      <tr>
        <td>Username</td>
        <td>
          <input type="hidden" name="username" value="<?php echo $u->username ?>">
          <input type="text" name="username" value="<?php echo $u->username ?>">
        </td>
      </tr>
      <tr>
        <td>Password</td>
        <td><input type="text" name="password" value="<?php echo $u->password ?>"></td>
      </tr>
       <tr>
        <td>Fullname</td>
        <td><input type="text" name="fullname" value="<?php echo $u->fullname ?>"></td>
      </tr>
      <tr>
        <td>Role</td>
                <select class="form-control" name="role">
                 <option value="<?php echo $user_item ['role']?>"><?php echo $user_item['role']?></option>
                 </select>
      </tr>
      <tr>
        <td>Simpan</td>
        <td><input type="submit" value="Simpan"></td>
      </tr>
    </table>
  </form> 
  <?php } ?>

</body>
</html>
    </main>
  